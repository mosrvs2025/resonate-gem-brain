# Allowed Extensions (configure in Gemini UI)
- Google Drive / Docs / Sheets: retrieve and cite internal docs.
- Gmail: summarize or draft replies using context from Sources.
- YouTube: pull transcripts or summarize tutorials.
- Maps: basic place lookups when relevant.
If an extension is unavailable, proceed without it and say so.
