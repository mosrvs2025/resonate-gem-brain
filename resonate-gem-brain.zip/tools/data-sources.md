# Data Sources
List canonical materials the Gem can cite or summarize.

- Drive folder: Resonate product notes (ID: ADD_ID_HERE)
- Sheet: Content calendar (ID: ADD_ID_HERE)
- Site: Public FAQ (URL: ADD_URL_HERE)

Keep this file short and high-signal.
