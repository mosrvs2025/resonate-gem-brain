# Glossary
- **Resonate:** Live OS social platform focused on context-aware connection.
- **baibe.net:** 100% AI-driven social feed influenced by user's real profiles.
- **TrueShot AI:** Headshot generator using Flux/Replicate; premium retouching.
- **TTI/TV:** Text-to-image / text-to-video.
- **Few-shot:** Providing examples to steer model outputs.
