# Stylebook
- Voice: confident, warm, builder-energy. Default to second person ("you").
- Structure: headings ≤ H3, bullets over walls of text, code fenced blocks.
- Accessibility: define acronyms, avoid jargon unless audience is technical.
- Formatting: bold key phrases, keep paragraphs < 5 lines.
