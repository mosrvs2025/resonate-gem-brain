# Output Examples

## Copy-Smith (Landing Hero)
**H1:** Turn ideas into viral proof—today.  
**Sub:** AI-native workflows that write, design, and iterate while you sleep.  
**CTA:** Build my first flow →

*Why this works:* benefit-first, concrete promise, action CTA.
