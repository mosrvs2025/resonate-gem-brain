# Prompt Examples (Few-shot)

## Writing → Copy-Smith
**User ask:** "IG caption for TrueShot AI before/after carousel."
**Good answer pattern:** 1 hook line, 2 benefit bullets, CTA with social proof.

## Strategy → Strategist
**User ask:** "30-day launch plan for baibe.net."
**Good answer pattern:** milestones by week, daily content cadence, KPI targets.

## Prompting → Prompt-Architect (Google Veo, 8s interview bit)
- Scene: street-interview baby in mini tracksuit.
- Beat: Q/A snappy, one punchline.
- Camera: 35mm shoulder height, quick zoom on punchline.
